<?php
    require_once '../controllers/notaController.php';

    $notaController = new notaController();
    $rota =  $_POST['rota'];

    switch($rota){
        case "cadastrar":
            $idNota = $_POST['idNota'];
            $descricaoNota = $_POST['descricaoNota'];
            $notaController->cadastrarNota($idNota, $descricaoNota);
            break;
        
        case "excluir":
            $idNota = intval($_POST['idNota']);
            $notaController->excluirNota($idNota);
            break;

        case "salvar":
            $idNota = $_POST['idNota'];
            $descricaoNota = $_POST['descricaoNota'];
            $notaController->atualizarNota($idNota, $descricaoNota);
            break;
    }

?>