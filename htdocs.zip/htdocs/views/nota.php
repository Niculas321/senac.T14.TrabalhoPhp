<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notas</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<?php
    require_once '../models/notaModel.php';

    session_start();

    if ($_SESSION['esta_logado'] !== true){
        header('Location: login.php');
        exit();
    }

    $notaModel = new notaModel();

    $idNota = intval($_GET['idNota']);
    $nota = $notaModel->buscarNotaPorId($idNota);
?>
<body>
    <header>
        <?php
            if ($_SESSION['id_tipo_usuario'] == 1) {
                require_once '../public/html/menuAdmin.html';
            }
            else {
                require_once '../public/html/menuAluno.html';
            }
        ?>
        <h1>Editar nota</h1>
    </header>
    <main>
        <h1><?= $nota->descricaoNota; ?></h1>
    </main> 
</body>
</html>