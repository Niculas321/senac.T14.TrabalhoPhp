function validarCamposCadastrarNota(event) {
    const idNota = document.getElementById('idNota').value;
    const descricaoNota = document.getElementById('descricaoNota').value;
    const valor = document.getElementById('valor').value;

    if (idNota == 0 || descricaoNota == '' || valor == '') {
        alert('Preencha os campos corretamente!');

        event.preventDefault();

        return false;
    }

    return true;
}

function validarCamposLogin(event) {
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (email === '' || senha === '') {
        alert('Preencha os campos corretamente!');

        event.preventDefault();

        return false;
    }

    return true;
}

function validarCamposCadastro(event) {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (nome === '' || email === '' || senha === '') {
        alert('Preencha os campos corretamente!');

        event.preventDefault();

        return false;
    }

    return true;
}
