<?php
    require_once '../models/notaModel.php';

    class notaController {
        public function cadastrarNota(int $idNota, string $descricaoNota, string $valor) {
            $notaModel = new notaModel();

            $nota = new notaModel(null, $idNota, $descricaoNota, $valor);

            $retorno = $notaModel->cadastrarNota($nota);

            if ($retorno) {
                header('Location: ../views/principal.php');
            }
            else {
                header('Location: ../views/cadastrarNota.php');
            }
            exit();
        }
        public function excluirNota(int $idNota) {
            $notaModel = new notaModel();
            $notaModel->excluirNota($idNota);
            header('Location: ../views/principal.php');
            exit();
        }
        public function atualizarNota(int $idNota, string $descricaoNota, string $valor) {
            $notaModel = new notaModel();

            $nota = new notaModel($idNota, $descricaoNota, $valor);

            $retorno = $notaModel->atualizarNota($nota);

            if ($retorno) {
                header('Location: ../views/listarNota.php');
            }
            else {
                header("Location: ../views/editarNota.php?idNota=$idNota");
            }

            exit();
        }
    }
?>