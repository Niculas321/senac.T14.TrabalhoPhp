<?php
    require_once 'conexao.php';

    class notaDAO {
        public function cadastrarNota(notaModel $nota) {
            $conexao = (new conexao())->getConexao();

            $sql = "INSERT INTO nota VALUES(null, :descricaoNota, :valor);";

            $stmt = $conexao->prepare($sql);       
            $stmt->bindParam(':descricaoNota', $nota->descricaoNota);
            $stmt->bindParam(':valor', $nota->valor);
            return $stmt->execute();
        }

        public function buscarNota() {
            $conexao = (new conexao())->getConexao();

            $sql = "SELECT * FROM nota;";

            $stmt = $conexao->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        public function buscarNotaPorId(int $idNota) {
            $conexao = (new conexao)->getConexao();

            $sql = "SELECT * FROM nota WHERE idNota = :idNota;";

            $stmt = $conexao->prepare($sql);
            $stmt->bindParam(':idNota', $idNota);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        public function excluirNota(int $idNota) {
            $conexao = (new conexao())->getConexao();

            $sql = "DELETE FROM nota WHERE idNota = :idNota";

            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':idNota', $idNota);
            return  $stmt->execute();
        }

        public function atualizarNota(notaModel $nota) {
            $conexao = (new conexao())->getConexao();

            $sql = "UPDATE nota SET idNota = :idNota, descricaoNota = :descricaoNota, valor = :valor WHERE idNota = :idNota;";

            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':idNota', $nota->idNota);
            $stmt->bindValue(':descricaoNota', $nota->descricaoNota);
            $stmt->bindValue(':valor', $nota->valor);                    
            return $stmt->execute();
        }
    }
?>