<?php
    require_once 'DAL/usuarioDAO.php';

    class notaModel {
        public ?int $idUsuario;
        public ?int $idTipoUsuario;
        public ?string $nome;
        public ?string $email;
        public ?string $senha;

        public function __construct(?int $idNota = null, ?int $idTipoUsuario = null, ?string $nome = null, ?string $email = null, ?string $senha = null) {
            $this->idNota = $idNota;
            $this->idTipoUsuario = $idTipoUsuario;
            $this->nome = $nome;
            $this->email = $email;
            $this->senha = $senha;
        }
            # FUNÇAO PARA BUSCAR ALGUM USUARIO COM BASE NOS CAMPOS DE PREENCHIMENTO
        public function buscarUsuarioPorNomeEmailESenha(string $nome, string $email, string $senha) {
            $usuarioDAO = new uduarioDAO();
            $retorno = $usuarioDAO->buscarUsuarioPorNomeEmailESenha($nome, $email, $senha);
            return $retorno;
        }
            # FUNÇAO PARA ADICIONAR ALGUM USUARIO
        public function inserirUsuario(string $nome, string $email, string $senha) {
            $usuarioDAO = new usuarioDAO();
            $retorno = $usuarioDAO->inserirUsuario($nome, $email, $senha);
            return $retorno;
        }
            # FUNÇAO PARA EXCLUIR UM USUARIO
        public function excluirUsuario(string $nome, string $email, string $senha) {
            $usuarioDAO = new usuarioDAO();
            $retorno = $usuarioDAO->excluirUsuario($nome, $email, $senha);
            return $retorno;
        }

    }
?>